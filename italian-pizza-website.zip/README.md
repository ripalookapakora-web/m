# Italian Pizza — website

Open `index.html` directly in a browser, or deploy the folder to Netlify/GitHub Pages.

Notes:
- Menu prices are intentionally not invented. Set `price` values in CONFIG.menu when confirmed.
- WhatsApp number is centralized in `CONFIG.whatsapp`.
- Verified branches are centralized in `CONFIG.branches`.
- Location selection only calculates against verified branches.
- Images use remote Unsplash URLs; for production, replace them with the restaurant's own optimized photography.
